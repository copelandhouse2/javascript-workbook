import React from 'react';

const Square = (props)=> {

  return (
    /***** CODE HERE ****/
    <div>
      <h3>{props.id}</h3>
      <h4>{props.money}</h4>
      </div>
  );  // return

}  // functional component Square

export default Square;
