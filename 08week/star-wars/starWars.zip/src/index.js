import React from 'react';
import ReactDOM from 'react-dom';
import StarWars from './StarWars';

ReactDOM.render(<StarWars />, document.getElementById('root'));
