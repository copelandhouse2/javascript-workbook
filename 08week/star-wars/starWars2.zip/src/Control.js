import React, { Component } from 'react';
import {Button, Icon} from 'react-materialize'

class Control extends Component {

  render() {
    /***** CODE HERE ****/
    return (
      <div id="control">
        <h1>Star Wars Jeopardy</h1>
        <button type="button" onClick={this.props.startClick}>Start Game</button>
        <Button waves='light'>EDIT ME<Icon left>save</Icon></Button>
      </div>
    );
  }  // return

}  // class Control

export default Control;
